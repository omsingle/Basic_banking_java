package com.fullstack.controller;

import java.nio.channels.Pipe.SourceChannel;
import java.util.Scanner;

import com.fullstack.model.Customer;
import com.fullstack.service.CustomerService;

public class CustomerController {
	public static void main(String[] args) {

		CustomerService service = new CustomerService();
		Customer customer = new Customer(12345, "Fullstack");

		Scanner scanner = new Scanner(System.in);

		boolean flag = false;
		do {
			System.out.println("Please Enter AccntNumber & Password: ");

			long accNumber = scanner.nextLong();

			String password = scanner.next();

			if (customer.getCustAccountNumber() == accNumber && customer.getCustPassword().equals(password)) {
				System.out.println("Welcome to Indian Bank ");
				flag = false;
			} else {
				System.out.println("Invalid Credentails! \n Please Try Again!!!");
				flag = true;
			}
		} while (flag);
		do {
			System.out.println("Please Enter Your Choice: \n 1. Deposit \n 2. Withdraw \n 3. Transfer \n 4. Logout");
			int ch = scanner.nextInt();
			switch (ch) {
			case 1: {
				service.deposit();
				break;
			}
			case 2: {
				service.withdraw();
				break;
			}
			case 3: {
				service.transfer();
				break;
			}
			case 4: {
				service.logout();
				break;
			}
			default:
				System.out.println("Invalid Choice");
				break;
			}
		} while (true);
	}
}
