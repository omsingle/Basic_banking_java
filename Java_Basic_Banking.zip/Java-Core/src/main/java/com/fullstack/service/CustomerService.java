package com.fullstack.service;

import java.nio.channels.Pipe.SourceChannel;
import java.util.Scanner;

import javax.swing.text.DefaultEditorKit.CutAction;

public class CustomerService {

	double custAccBal = 10000;
	int amount, otp, generatedOTP;

	Scanner scanner = new Scanner(System.in);

	public void deposit() {
		System.out.println("\n Before Deposit Cust Balance :" + custAccBal);
		System.out.println("\n Please Enter Amount For Deposit: ");
		amount = scanner.nextInt();
		custAccBal += amount;
		System.out.println("\n Your Accnt Balance is : " + custAccBal);
	}

	public void withdraw() {
		System.out.println("\n Before Withdraw Your Accnt Balance is :" + custAccBal);
		System.out.println("Enter the Amount You Want To Withdraw: ");
		amount = scanner.nextInt();
		if (custAccBal > amount) {
			custAccBal -= amount;
			System.out.println("\n After Withdraw Your Accnt Balance is : " + custAccBal);
		} else {
			System.out.println("Insufficient Funds");
		}
	}

	public void transfer() {
		System.out.println("\n Before Transfer Your Accnt Balance is: " + custAccBal);
		System.out.println("\n Please Enter Amount For Transfer: ");
		amount = scanner.nextInt();
		if (custAccBal > amount) {
			generatedOTP = generateOTP();

			System.out.println("\n Please Enter Otp: " + generatedOTP);
			otp = scanner.nextInt();

			if (generatedOTP == otp) {
				custAccBal -= amount;
				System.out.println("\n After Transfer Your Balance : " + custAccBal);
			} else {
				System.out.println("Invalid OTP");
			}
		} else {
			System.out.println("Insufficient Funds");
		}
	}

	public void logout() {
		System.out.println("Logout Successfully");
		System.exit(0);
	}

	int generateOTP() {
		return (int) (Math.random() * 9000 + 1000);
	}
}
